﻿using Xunit;

[assembly: CollectionBehavior(DisableTestParallelization = true)]