# NModbus.SerialPortStream

Legacy. This should no longer be needed for linux devices.