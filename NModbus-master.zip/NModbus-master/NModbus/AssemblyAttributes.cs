﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("NModbus.UnitTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]